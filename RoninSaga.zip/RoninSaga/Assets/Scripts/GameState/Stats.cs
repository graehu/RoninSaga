﻿using UnityEngine;
using System.Collections;

public class Stats 
{
	#region public variables
	public float strength;
	public float magic;
	public float speed;
	#endregion
}
