﻿using UnityEngine;
using System.Collections.Generic;

public class Path : MonoBehaviour 
{
    public List<PathNode> nodes = new List<PathNode>();

    void Start()
    {
    }

}
